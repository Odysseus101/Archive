#! /bin/bash

echo Hallo world