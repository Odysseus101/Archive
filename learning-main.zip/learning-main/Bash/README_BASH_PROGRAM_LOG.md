This will be where I put explenations of all the so that you can eaysily navigate the programs

[Title](Link to program)
a sufficiant explination of how the program works

[Hallo_World.sh](https://github.com/Odysseus101/learning/blob/main/Bash/Hallo_world.sh)

This was a easy little project I did in a couble of languages, plan on adding more to it like going through different types of thing's you can di in each program

[directory_overveiw.sh](https://github.com/Odysseus101/learning/blob/main/Bash/directory-overveiw.sh)

just a small program I use to look over my main directory's to re-order
