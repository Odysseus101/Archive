public class Hallo_world
{
    public static void main(String[] args)
    {
        System.out.println("Hallo World");
    }
}