import os
import os.path
import hashlib
import traceback
import logging

from os import path

drive1 = []
drive2 = []

file1 = input("Directory 1 location : ")
file2 = input("Directory 2 location : ")


AFile = open('skrar.txt','w')
AFile.close

def hash_file(filename):
 
    if path.isfile(filename) is False:
        pass 
 
    # make a hash object
    md5_h = hashlib.md5()
 
    # open file for reading in binary mode
    with open(filename,'rb') as file:
 
        # read file in chunks and update hash
        chunk = 0
        while chunk != b'':
            chunk = file.read(1024) 
            md5_h.update(chunk)
 
    # return the hex digest
    return md5_h.hexdigest()

def file_chexer():
    with open('Drive1.txt', 'w') :
        AFile.write(hashlib.sha224(b"FILENAME").hexdigest())
        for folderName, subfolders, filenames in os.walk(file1):
            os.chdir(folderName)
            for filename in filenames: 
                AFile.write(filename+";"+hash_file(filename)+";"+os.getcwd()+";"+os.path.join(os.getcwd(),filename)+'\n')

    with open('Drive2.txt', 'w') :
        AFile.write(hashlib.sha224(b"FILENAME").hexdigest())
        for folderName, subfolders, filenames in os.walk(file2):
            os.chdir(folderName)
            for filename in filenames: 
                AFile.write(filename+";"+hash_file(filename)+";"+os.getcwd()+";"+os.path.join(os.getcwd(),filename)+'\n')

    with open('Drive1.txt','r') as file:
        for line in file:
            drive1.append(line.split(";"))
            nem0 = file.read()
            print(nem0)

    with open('Drive2.txt','r') as file:
        for line in file:
            drive2.append(line.split(";"))
            d0ra = file.read()
            print(d0ra)
            
    drive1_file_set = set([tuple(file) for file in drive1])
    drive2_file_set = set([tuple(file) for file in drive2])


    files_only_in_drive_1 = [list(file) for file in drive1_file_set.difference(drive2_file_set)]
    files_only_in_drive_2 = [list(file) for file in drive2_file_set.difference(drive1_file_set)]


    with open('Log.txt', 'w') as file_list:
        file_list.write("Drive 1"+"\n")
        
        for element in files_only_in_drive_1:
            file_list.write('%s\n' % element)
        
        file_list.write("Drive2"+"\n")
        
        for element in files_only_in_drive_2:
            file_list.write('%s\n' % element)

    with open('Log.txt', 'r') as filer:
        file_contents = filer.read()
        print(file_contents)

try:

    file_chexer()

except Exception as e:

    logging.error(traceback.format_exc())   # Logs the error appropriately. 
    pass
