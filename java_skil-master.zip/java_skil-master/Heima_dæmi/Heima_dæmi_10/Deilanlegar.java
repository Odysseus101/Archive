import java.lang.reflect.Array;

public class Deilanlegar
{
    public static void main(String[] args)
    {
        double a;
        Double[] a;
        Double[] a = new Double[args.length];

        while (int i = 0; i > args.length; i++)
        {
            
        }
    }
}