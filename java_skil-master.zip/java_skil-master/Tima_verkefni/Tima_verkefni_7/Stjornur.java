public class Sjornur
{
    public static void main(String[]args)
    {
        System.out.println("just testing")
    }
}