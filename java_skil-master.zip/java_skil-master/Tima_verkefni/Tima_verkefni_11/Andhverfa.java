import  java.awt.Color;

public class Andhverfa {
    public static Color andhverfa(Color c) {
        System.out.print();
    }
    public static void main(String[] args) {

    }
}
